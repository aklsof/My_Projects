/**
 * Name: Sofiane Akli
 * University Of Arizona Global Campus
 * Class: CPT 307
 * Instructor: Pete Limon
 * submission date: August 5, 2024
 */
import java.util.*;
import java.io.*;

class Equipment {
    String name;
    double gain;
    double cost;
    double roi;

    public Equipment(String name, double gain, double cost) {
        this.name = name;
        this.gain = gain;
        this.cost = cost;
        this.roi = roicalc();
    }

    public double roicalc() {
        return (gain - cost) / cost;
    }
}

public class ROI {

    static LinkedList<Equipment> equipment1 = new LinkedList<>();

    public static void main(String[] args) {
        // Handle file path more robustly
        String filePath = "c:\\brands.txt"; 

        loadDataFile(filePath);
        quickSort(0, equipment1.size() - 1);

        System.out.println("Equipments sorted by ROI (highest to lowest):");
        printList(equipment1);
    }

    public static void loadDataFile(String fileName) {
        try (Scanner fileScanner = new Scanner(new File(fileName))) {
            System.out.println("Reading data from file");
        	while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();  

                String[] data = line.split(";");

                if (data.length == 3) {
                    String name = data[0];
                    double gain = Double.parseDouble(data[1]);
                    double cost = Double.parseDouble(data[2]);

                    Equipment newEquipment = new Equipment(name, gain, cost);
                    equipment1.add(newEquipment); // Add to the list
                } else {
                    System.err.println("Invalid data format in line: " + line);
                }
            }
            System.out.println("Data loading complete");
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + fileName);
        }
    }
    
   // ... (quickSort and partition methods remain the same) ...

    public static void printList(LinkedList<Equipment> list) {
        for (Equipment e : list) {
            System.out.println(e.name + ": " + e.roi);
        }
    }

    public static void quickSort(int low, int high) {
        if (low < high) {
            int pivotIndex = partition(low, high);
            quickSort(low, pivotIndex - 1);
            quickSort(pivotIndex + 1, high);
        }
    }

    private static int partition(int low, int high)  
 {
        Equipment pivot = equipment1.get(high);
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (equipment1.get(j).roi >= pivot.roi) { // Descending order
                i++;
                Collections.swap(equipment1, i, j);
            }
        }
        Collections.swap(equipment1, i + 1, high);
        return i + 1;
    }
}