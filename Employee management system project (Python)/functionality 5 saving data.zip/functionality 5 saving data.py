import time

employees = []
employees_number = 0


def export_employees_to_file():
    """This function exports employee information to a text file"""
    filename = input("Enter the filename to export employee data (e.g., employees.txt): ")
    try:
        file = open(filename, "w")
        for employee in employees:
            employee_data = ",".join(employee.values())  # Convert employee dictionary to a comma-separated string
            file.write(employee_data + "\n")
        print(f"Employee information successfully exported to {filename}")
    except FileNotFoundError:
        print(f"Error: Could not create file '{filename}'.")


def import_employees_from_file():
    """This function imports employee information from a text file"""
    filename = input("Enter the filename containing employee data (e.g., employees.txt): ")
    try:
        file = open(filename, "r")
        imported_employees = []
        for line in file:
            employee_data = line.strip()  # convert each line to an item of a list
            employee_info = employee_data.split(",")  # each line has a dictionary information
            # Create a dictionary from the employee information
            employee = {
                "employeeName": employee_info[0],
                "employeeSSN": employee_info[1],
                "employeePhone": employee_info[2],
                "employeeEmail": employee_info[3],
                "employeeSalary": employee_info[4],
            }
            imported_employees.append(employee)
        global employees
        employees = imported_employees
        print(f"Employee information successfully imported from {filename}")
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")


def add_employee():
    """this function adds a new employee to the list"""
    employee = {"employeeName": input("Enter the name: "),
                "employeeSSN": input("Enter the SSN : "),
                "employeePhone": input("Enter the phone number (format: (XXX)XXX-XXXX): "),
                "employeeEmail": input("Enter the email address: "),
                "employeeSalary": input("Enter the salary (format: $XXXX): ")}
    employees.append(employee)


def search_employee_by_ssn():
    """This function searches for an employee based on their SSN"""
    ssn = input("Enter the SSN of the employee you want to search: ")
    found = False
    for employee in employees:
        if employee["employeeSSN"] == ssn:
            print_employee(employees.index(employee))
            found = True
            break

    if not found:
        print("Employee with the entered SSN not found.")


def edit_employee_info():
    """This function allows editing information of an existing employee"""
    ssn = input("Enter the SSN of the employee you want to edit: ")
    found = False
    for index, employee in enumerate(employees):
        if employee["employeeSSN"] == ssn:
            print(f"Current information for employee {employee['employeeName']}")
            print_employee(index)
            edit_choice = input(
                "What information do you want to edit? choose by number \n 1. name\n2. phone\n 3. email\n 4.salary ")
            if edit_choice == '1':
                edit_choice = 'employeeName'
            elif edit_choice == '2':
                edit_choice = 'employeePhone'
            elif edit_choice == '3':
                edit_choice = 'employeeEmail'
            elif edit_choice == '4':
                edit_choice = 'employeeSalary'
            else:
                print('bad selection')
            if edit_choice in employee:
                new_value = input(f"Enter the new value for {edit_choice}: ")
                employee[edit_choice] = new_value
                print(f"Employee information for {employee['employeeName']} updated successfully!")
            else:
                print(f"{edit_choice} is not a valid field to edit.")
            found = True
            break

    if not found:
        print("Employee with the entered SSN not found.")


def print_employee(index):
    employeeInfo = employees[index]
    print(
        f'------------------------------------------------------------\n'
        f'----------------{employeeInfo['employeeName']}--------------\n'
        f'-------------------------------------------------------------\n'
        f'SSN Number:  {employeeInfo['employeeSSN']}   \n'
        f'Phone number:  {employeeInfo["employeePhone"]}  \n'
        f'Employee email: {employeeInfo["employeeEmail"]}  \n'
        f'Rmployee Salary: $ {employeeInfo["employeeSalary"]}  \n'
        f'--------------------------------------------------------------\n'
        f'--------------------------------------------------------------\n')

def print_all_employees():
    i = 0
    while i < len(employees):
        print_employee(i)
        i += 1


def main():
    while True:
        global employees_number
        employees_number = len(employees)
        print('-----------------------------------Employee Management System-------------------')
        print('            There are ( %d ) employees in the system           ' %employees_number)
        print('--------------------------------------------------------------------------------')
        select = int(input(
            '1. Add a new employee to the database\n'
            '2. print all the employees \n'
            '3. Search employee by SSN \n'
            '4. Edit an employee\n'
            '5. Export employee information to a text file \n'
            '6. Import employee information from a text file \n'
            '0. Exit the program  \n'
            '-------------------------------------------------------------------------------\n'
            'Please make your selection number from the list '))

        if select == 0:
            break
        elif select == 1:
            add_employee()
        elif select == 2:
            print_all_employees()
            time.sleep(7)
        elif select == 3:
            search_employee_by_ssn()
        elif select == 4:
            edit_employee_info()
        elif select == 5:
            export_employees_to_file()
        elif select == 6:
            import_employees_from_file()
        else:
            print('That is not a correct selection, try again')


if __name__ == "__main__":
    main()
