<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Security checks
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user']) || $_SESSION['user']->userType !== 'administrator') {
    header("Location: index.php");
    exit();
}

$action = $_POST['action'] ?? '';
$courseID = filter_input(INPUT_POST, 'courseID', FILTER_VALIDATE_INT);

if (!$courseID) {
    $_SESSION['error_message'] = "Invalid Course ID provided.";
    header('Location: manage_courses.php');
    exit();
}

try {
    $database = new Database();
    $conn = $database->getPDO();

    if ($action === 'update') {
        // Sanitize and retrieve form data
        $courseCode = htmlspecialchars($_POST['courseCode']);
        $courseName = htmlspecialchars($_POST['courseName']);
        $description = htmlspecialchars($_POST['description']);
        $instructor = htmlspecialchars($_POST['instructor']);
        $semester = htmlspecialchars($_POST['semester']);
        $maxCapacity = filter_input(INPUT_POST, 'maxCapacity', FILTER_VALIDATE_INT);

        $sql = "UPDATE Courses SET courseCode = :courseCode, courseName = :courseName, description = :description, instructor = :instructor, semester = :semester, maxCapacity = :maxCapacity WHERE courseID = :courseID";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':courseCode' => $courseCode,
            ':courseName' => $courseName,
            ':description' => $description,
            ':instructor' => $instructor,
            ':semester' => $semester,
            ':maxCapacity' => $maxCapacity,
            ':courseID' => $courseID
        ]);
        $_SESSION['success_message'] = "Course updated successfully!";

    } elseif ($action === 'delete') {
        $sql = "DELETE FROM Courses WHERE courseID = :courseID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':courseID', $courseID, PDO::PARAM_INT);
        $stmt->execute();
        $_SESSION['success_message'] = "Course deleted successfully!";
    }

} catch (PDOException $e) {
    error_log("Manage Course Error: " . $e->getMessage());
    $_SESSION['error_message'] = "A database error occurred.";
}

header('Location: manage_courses.php');
exit();