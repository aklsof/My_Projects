<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Security checks
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user']) || $_SESSION['user']->userType !== 'student') {
    header("Location: index.php");
    exit();
}

$action = $_POST['action'] ?? '';
$courseID = filter_input(INPUT_POST, 'courseID', FILTER_VALIDATE_INT);
$studentID = $_SESSION['user']->userID;
$redirectPage = 'enroll.php'; // Default redirect

if (!$courseID) {
    die("Invalid Course ID.");
}

try {
    $database = new Database();
    $conn = $database->getPDO();
    $conn->beginTransaction();

    switch ($action) {
        case 'enroll':
            // Check if already enrolled
            $stmt = $conn->prepare("SELECT COUNT(*) FROM Enrollments WHERE userID = ? AND courseID = ?");
            $stmt->execute([$studentID, $courseID]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception("You are already enrolled in this course.");
            }

            // Check for space
            $stmt = $conn->prepare("SELECT maxCapacity, (SELECT COUNT(*) FROM Enrollments WHERE courseID = ?) as enrolledCount FROM Courses WHERE courseID = ?");
            $stmt->execute([$courseID, $courseID]);
            $courseInfo = $stmt->fetch();
            
            if ($courseInfo['enrolledCount'] >= $courseInfo['maxCapacity']) {
                 throw new Exception("This course is full. You can join the waitlist.");
            }

            $stmt = $conn->prepare("INSERT INTO Enrollments (userID, courseID) VALUES (?, ?)");
            $stmt->execute([$studentID, $courseID]);
            $_SESSION['success_message'] = "Successfully enrolled!";
            $redirectPage = 'enrolled_courses.php';
            break;

        case 'waitlist':
            $stmt = $conn->prepare("INSERT INTO WaitingLists (userID, courseID) VALUES (?, ?)");
            $stmt->execute([$studentID, $courseID]);
            $_SESSION['success_message'] = "Successfully joined the waitlist.";
            $redirectPage = 'my_waitlist.php';
            break;

        case 'withdraw':
            $stmt = $conn->prepare("DELETE FROM Enrollments WHERE userID = ? AND courseID = ?");
            $stmt->execute([$studentID, $courseID]);
            
            // SRS LOGIC: Promote first person from waitlist if available
            $waitlistStmt = $conn->prepare("SELECT userID FROM WaitingLists WHERE courseID = ? ORDER BY addedTimestamp ASC LIMIT 1");
            $waitlistStmt->execute([$courseID]);
            $promotedUserID = $waitlistStmt->fetchColumn();

            if ($promotedUserID) {
                // Add to enrollments
                $enrollStmt = $conn->prepare("INSERT INTO Enrollments (userID, courseID) VALUES (?, ?)");
                $enrollStmt->execute([$promotedUserID, $courseID]);

                // Remove from waitlist
                $removeStmt = $conn->prepare("DELETE FROM WaitingLists WHERE userID = ? AND courseID = ?");
                $removeStmt->execute([$promotedUserID, $courseID]);
            }
            $_SESSION['success_message'] = "Successfully withdrawn from the course.";
            $redirectPage = 'enrolled_courses.php';
            break;

        case 'leave_waitlist':
            $stmt = $conn->prepare("DELETE FROM WaitingLists WHERE userID = ? AND courseID = ?");
            $stmt->execute([$studentID, $courseID]);
            $_SESSION['success_message'] = "You have left the waitlist.";
            $redirectPage = 'my_waitlist.php';
            break;
    }
    $conn->commit();
} catch (Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    $_SESSION['error_message'] = $e->getMessage();
}

header("Location: $redirectPage");
exit();