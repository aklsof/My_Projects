<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Student-only access
if (!isset($_SESSION['user']) || $_SESSION['user']->userType !== 'student') {
    header("Location: index.php");
    exit();
}
$studentID = $_SESSION['user']->userID;

try {
    $database = new Database();
    $conn = $database->getPDO();
    $sql = "SELECT c.* FROM Courses c JOIN Enrollments e ON c.courseID = e.courseID WHERE e.userID = :userID";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':userID' => $studentID]);
    $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching enrolled courses.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Courses</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <h2>My Enrolled Courses</h2>
        <hr>
        <?php if (empty($enrolled_courses)): ?>
            <p>You are not currently enrolled in any courses.</p>
        <?php else: ?>
            <table class="table table-hover">
                <thead>
                    <tr><th>Course Code</th><th>Course Name</th><th>Instructor</th><th>Semester</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($enrolled_courses as $course): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($course['courseCode']); ?></td>
                            <td><?php echo htmlspecialchars($course['courseName']); ?></td>
                            <td><?php echo htmlspecialchars($course['instructor']); ?></td>
                            <td><?php echo htmlspecialchars($course['semester']); ?></td>
                            <td>
                                <form action="enroll_process.php" method="POST" onsubmit="return confirm('Are you sure you want to withdraw from this course?');">
                                    <input type="hidden" name="courseID" value="<?php echo $course['courseID']; ?>">
                                    <input type="hidden" name="action" value="withdraw">
                                    <button type="submit" class="btn btn-sm btn-danger">Withdraw</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>