<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Admin-only access
if (!isset($_SESSION['user']) || $_SESSION['user']->userType !== 'administrator') {
    header("Location: index.php");
    exit();
}

$courseID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$courseID) {
    die("Invalid course ID.");
}

try {
    $database = new Database();
    $conn = $database->getPDO();
    $stmt = $conn->prepare("SELECT * FROM Courses WHERE courseID = :courseID");
    $stmt->bindParam(':courseID', $courseID);
    $stmt->execute();
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$course) {
        die("Course not found.");
    }
} catch (PDOException $e) {
    die("Error fetching course data.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Course</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <h2>Edit Course: <?php echo htmlspecialchars($course['courseName']); ?></h2>
        <hr>
        <form action="edit_course_process.php" method="POST">
            <input type="hidden" name="courseID" value="<?php echo $course['courseID']; ?>">
            <input type="hidden" name="action" value="update">

            <div class="mb-3">
                <label for="courseCode" class="form-label">Course Code</label>
                <input type="text" class="form-control" id="courseCode" name="courseCode" value="<?php echo htmlspecialchars($course['courseCode']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="courseName" class="form-label">Course Name</label>
                <input type="text" class="form-control" id="courseName" name="courseName" value="<?php echo htmlspecialchars($course['courseName']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($course['description']); ?></textarea>
            </div>
             <div class="mb-3">
                <label for="instructor" class="form-label">Instructor</label>
                <input type="text" class="form-control" id="instructor" name="instructor" value="<?php echo htmlspecialchars($course['instructor']); ?>">
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="semester" class="form-label">Semester</label>
                    <input type="text" class="form-control" id="semester" name="semester" value="<?php echo htmlspecialchars($course['semester']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="maxCapacity" class="form-label">Maximum Capacity</label>
                    <input type="number" class="form-control" id="maxCapacity" name="maxCapacity" value="<?php echo htmlspecialchars($course['maxCapacity']); ?>" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Update Course</button>
            <a href="manage_courses.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>