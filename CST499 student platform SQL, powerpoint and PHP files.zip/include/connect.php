<?php
// Database credentials for a local XAMPP environment
$dsn = 'mysql:host=localhost;dbname=mydata';
$dbusername = 'root';
$dbpassword = '';

/**
 * Database Connection Class
 * This class manages the connection to the database using PDO.
 * on connection failure, allowing the calling script to handle the error gracefully.
 */
class Database {
    private $conn;

   
    public function __construct() {
        global $dsn, $dbusername, $dbpassword;
        try {
            $this->conn = new PDO($dsn, $dbusername, $dbpassword);
            // Set the PDO error mode to exception. This is a crucial step.
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {

            error_log("Database Connection Failed: " . $e->getMessage());

           throw $e;// throw the error
           // removed session management
        }
    }

    public function getPDO() {
        return $this->conn;
    }
}
?>

