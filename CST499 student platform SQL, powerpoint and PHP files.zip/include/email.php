<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require_once __DIR__ . '/../vendor/autoload.php';

class EmailService {
    private $mailer;

    public function __construct() {
        $this->mailer = new PHPMailer(true);
        $this->configure();
    }

    private function configure() {
        try {
            // Server settings
            $this->mailer->isSMTP();
            $this->mailer->Host       = 'smtp-mail.outlook.com';
            $this->mailer->SMTPAuth   = true;
            $this->mailer->Username   = 'admplatform@outlook.com'; // Your email
            $this->mailer->Password   = 'Qwerty20251950';          // Your password
            $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mailer->Port       = 587;

            // Sender
            $this->mailer->setFrom('admplatform@outlook.com', 'Student Platform');
        } catch (Exception $e) {
            // Handle configuration errors, perhaps log them
            error_log("PHPMailer configuration error: {$this->mailer->ErrorInfo}");
        }
    }

    public function sendPasswordResetCode($toEmail, $code) {
        try {
            // Recipient
            $this->mailer->addAddress($toEmail);

            // Content
            $this->mailer->isHTML(true);
            $this->mailer->Subject = 'Your Password Reset Code';
            $this->mailer->Body    = "
                <html>
                <body>
                    <h2>Password Reset Request</h2>
                    <p>We received a request to reset your password. Use the code below to complete the process.</p>
                    <p>Your code is: <strong>$code</strong></p>
                    <p>This code will expire in 15 minutes.</p>
                    <p>If you did not request a password reset, please ignore this email.</p>
                </body>
                </html>";
            $this->mailer->AltBody = "Your password reset code is: $code. It will expire in 15 minutes.";

            $this->mailer->send();
            return true;
        } catch (Exception $e) {
            error_log("Message could not be sent. Mailer Error: {$this->mailer->ErrorInfo}");
            return false;
        }
    }
}
?>