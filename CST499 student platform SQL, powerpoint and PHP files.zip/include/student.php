<?php

require_once __DIR__ . '/user.php';

/**
 * Class Student
 * Represents a student, inheriting from the User class.
 */
class Student extends User
{
    public function __construct(
        $userID,
        $email,
        $firstName,
        $lastName,
        $phone = null,
        $address = null,
        $username, 
        $birthdate 
    ) {
        // Now $username and $birthdate are correctly passed to the parent
        parent::__construct($userID, $email, $firstName, $lastName, $phone, $address, 'student',  $username, $birthdate);
    }
}
?>