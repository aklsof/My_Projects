<?php

require_once __DIR__ . '/user.php';

/**
 * Class Administrator
 * Represents an administrator, inheriting from the User class.
 */
class Administrator extends User
{
    public function __construct(
        $userID,
        $email,
        $firstName,
        $lastName,
        $phone = null,
        $address = null,
        $username, 
        $birthdate 
    ) {
        // Pass userID to the parent constructor
        parent::__construct($userID, $email, $firstName, $lastName, $phone, $address, 'administrator',  $username, $birthdate);
    }
}
?>