<?php



/**
 * Class User
 * Represents a generic user with properties corresponding to the tbluser table.
 */
class User
{
    public $userID; 
    public $email;
    public $firstName;
    public $lastName;
    public $phone;
    public $address;
    public $userType;
    public $username;
    public $birthdate;
    public function __construct(
        $userID, 
        $email,
        $firstName,
        $lastName,
        $phone = null,
        $address = null,
        $userType = 'student',
        $username,
        $birthdate
        
    ) {
        $this->userID = $userID; 
        $this->email = $email;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->phone = $phone;
        $this->address = $address;
        $this->userType = $userType;
        $this->username = $username;
        $this->birthdate = $birthdate;
    }

    public function getFullName()
    {
        return $this->firstName . ' ' . $this->lastName;
    }
}