-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2025 at 08:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydata`
--
CREATE DATABASE IF NOT EXISTS `mydata` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mydata`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `courseID` int(11) NOT NULL,
  `courseCode` varchar(20) NOT NULL,
  `courseName` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `instructor` varchar(100) DEFAULT NULL,
  `semester` varchar(20) NOT NULL,
  `maxCapacity` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `courses`
--

TRUNCATE TABLE `courses`;
--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseID`, `courseCode`, `courseName`, `description`, `instructor`, `semester`, `maxCapacity`) VALUES
(1, 'Gen 401', 'General education class', 'This class teach the student the best way to study at the university', 'carol stivens', 'Fall 2025', 5),
(3, 'Gen 402', 'General education 2', 'Complementary to gen 401', 'carol stivens', 'Fall 2025', 2),
(4, 'CST 302', 'principles of Python', 'This class teach student the basics of python', 'John Brown', 'Winter 2026', 25);

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
CREATE TABLE `enrollments` (
  `userID` int(11) NOT NULL,
  `courseID` int(11) NOT NULL,
  `enrollmentDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `enrollments`
--

TRUNCATE TABLE `enrollments`;
--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`userID`, `courseID`, `enrollmentDate`) VALUES
(1, 1, '2025-10-06 16:35:44'),
(7, 1, '2025-10-06 16:39:16'),
(7, 3, '2025-10-06 16:39:12'),
(8, 1, '2025-10-06 16:44:29'),
(8, 3, '2025-10-06 19:05:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `userType` enum('student','administrator') NOT NULL DEFAULT 'student',
  `reset_token_hash` varchar(255) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `tbluser`
--

TRUNCATE TABLE `tbluser`;
--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `email`, `password`, `firstName`, `lastName`, `address`, `phone`, `userType`, `reset_token_hash`, `reset_token_expires_at`, `birthdate`, `username`) VALUES
(1, 'aklsof@gmail.com', '$2y$10$6Xg1HzLTTNXI6IjiTAUlGOp3EeOJIYS7cGVKX2GMj48ZDcXQaZYo2', 'Sofiane', 'Akli', '22816 28th Ave S', '2063339999', 'student', '$2y$10$1KxNRVkV0sk1ZFTE38kMy.A4lSLA9E72cE8rAmCoNmQNXJD/LkdlO', '2025-10-06 22:41:48', '1980-10-09', 'aklsof'),
(2, 'jacson@yahoone', '$2y$10$ITY6.hB8O57KwQHTLRRSSeKh5.3VrAQfdqmv5zUrdUECBmhbqHP2S', 'Robert ', 'Jackson', '2522 main st', '4501235554', 'student', NULL, NULL, NULL, 'jacson@yahoone'),
(3, 'Johnrobert@gmail.com', '$2y$10$PeUdEj3N0ruxmhTkEf7HIOrZLocKVz6T6aKFxme3aPE7nPhieLOdK', 'John', 'robert', '226 m st', '4202221455', 'student', NULL, NULL, NULL, 'Johnrobert@gmail.com'),
(4, 'joe@live.net', '$2y$10$SqNkf5h2mGyemmIwWUU6HOVNVOhSEIK8oDuOc/MK33Minv0M637CK', 'joe', 'masters', '78 ave s', '4152225656', 'student', NULL, NULL, NULL, 'joe@live.net'),
(5, 'john11@live.com', '$2y$10$sqvzLGzWWYLrVRIZrL2BOesn8rvrXYaYnGBLP1PUXIyTRi8qdSarC', 'SOFIANE', 'Akli', '22816 28TH AVE S', '2067750761', 'student', NULL, NULL, NULL, 'john11@live.com'),
(6, 'admin@University.edu', '$2y$10$qVhycpILzOuAzvnzgSfD4OgCVXRqe6CU/hNZ2vL8AfKN1E.QGXePa', 'Steve', 'notch', '22816 28TH AVE S', '2067750761', 'administrator', NULL, NULL, '1999-04-22', 'stevo'),
(7, 'robj@live.com', '$2y$10$4iyiQEgQwGLTZ.lj859Aze67/Y.sOSt1bEhzz22vsnXyMf9OJvXue', 'Robert ', 'Johnson', '2816 28TH AVE S', '2067750700', 'student', NULL, NULL, '0089-12-12', 'robj'),
(8, 'tara@mail.net', '$2y$10$6YTVHwx1T2XVqrnDNxTIo.YnQ9503ARXz1VgJi0jFHAkhEi2zS6Ca', 'Tara', 'tara', '22 street ave', '000000000', 'student', NULL, NULL, '1990-10-12', 'tara');

-- --------------------------------------------------------

--
-- Table structure for table `waitinglists`
--

DROP TABLE IF EXISTS `waitinglists`;
CREATE TABLE `waitinglists` (
  `userID` int(11) NOT NULL,
  `courseID` int(11) NOT NULL,
  `addedTimestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `waitinglists`
--

TRUNCATE TABLE `waitinglists`;
--
-- Dumping data for table `waitinglists`
--

INSERT INTO `waitinglists` (`userID`, `courseID`, `addedTimestamp`) VALUES
(1, 3, '2025-10-06 19:41:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseID`),
  ADD UNIQUE KEY `courseCode` (`courseCode`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`userID`,`courseID`),
  ADD KEY `fk_enrollments_course` (`courseID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Indexes for table `waitinglists`
--
ALTER TABLE `waitinglists`
  ADD PRIMARY KEY (`userID`,`courseID`),
  ADD KEY `fk_waitinglists_course` (`courseID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_enrollments_course` FOREIGN KEY (`courseID`) REFERENCES `courses` (`courseID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_enrollments_user` FOREIGN KEY (`userID`) REFERENCES `tbluser` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `waitinglists`
--
ALTER TABLE `waitinglists`
  ADD CONSTRAINT `fk_waitinglists_course` FOREIGN KEY (`courseID`) REFERENCES `courses` (`courseID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_waitinglists_user` FOREIGN KEY (`userID`) REFERENCES `tbluser` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
