<?php
// Enable error reporting for debugging purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session to manage user feedback messages
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include the database connection file
require_once __DIR__ . '/include/connect.php';

// --- Security & Validation Functions ---

/**
 * Validates password complexity.
 * Requirements: 12+ characters, uppercase, lowercase, number, special character.
 * @param string $password The password to validate.
 * @return bool True if the password meets complexity requirements, false otherwise.
 */
function isPasswordStrong($password) {
    return strlen($password) >= 12 &&
           preg_match('/[A-Z]/', $password) &&
           preg_match('/[a-z]/', $password) &&
           preg_match('/[0-9]/', $password) &&
           preg_match('/[\W_]/', $password);
}

/**
 * Checks if a given username or email already exists in the database.
 * @param PDO $conn The database connection object.
 * @param string $field The database column to check ('username' or 'email').
 * @param string $value The value to search for.
 * @return bool True if the value exists, false otherwise.
 */
function isValueTaken($conn, $field, $value) {
    // Whitelist the field to prevent SQL injection on the column name
    if (!in_array($field, ['username', 'email'])) {
        // This is a developer error, should not happen in production
        die("Invalid field provided for uniqueness check.");
    }
    // Use backticks around the field name and a prepared statement for the value
    $sql = "SELECT COUNT(*) FROM tbluser WHERE `$field` = :value";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':value', $value, PDO::PARAM_STR);
    $stmt->execute();
    return $stmt->fetchColumn() > 0;
}


// --- Main Processing Logic ---

// 1. Ensure the form was submitted using the POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_message'] = "Invalid request method.";
    header("Location: registration.php");
    exit();
}

// 2. Sanitize and retrieve all form inputs
// Replace deprecated FILTER_SANITIZE_STRING with htmlspecialchars and FILTER_DEFAULT
$firstname = htmlspecialchars(filter_input(INPUT_POST, 'firstname', FILTER_DEFAULT) ?? '');
$lastname = htmlspecialchars(filter_input(INPUT_POST, 'lastname', FILTER_DEFAULT) ?? '');
$username = htmlspecialchars(filter_input(INPUT_POST, 'username', FILTER_DEFAULT) ?? '');
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$password = $_POST['password'] ?? ''; // Password is not sanitized here, but validated for complexity
$address = htmlspecialchars(filter_input(INPUT_POST, 'address', FILTER_DEFAULT) ?? '');
$phone = htmlspecialchars(filter_input(INPUT_POST, 'phone', FILTER_DEFAULT) ?? '');
$birthdate = htmlspecialchars(filter_input(INPUT_POST, 'birthdate', FILTER_DEFAULT) ?? '');


// 3. Perform server-side validation
if (empty($firstname) || empty($lastname) || empty($username) || empty($email) || empty($password) || empty($address) || empty($phone) || empty($birthdate)) {
    $_SESSION['error_message'] = "All fields are required. Please fill out the entire form.";
    header("Location: registration.php");
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error_message'] = "Invalid email format.";
    header("Location: registration.php");
    exit();
}

if (!isPasswordStrong($password)) {
    $_SESSION['error_message'] = "Password is not strong enough. It must be at least 12 characters and include uppercase, lowercase, numbers, and special characters.";
    header("Location: registration.php");
    exit();
}

// 4. Check for uniqueness and process data
try {
    $database = new Database();
    $conn = $database->getPDO();

    if (isValueTaken($conn, 'username', $username)) {
        $_SESSION['error_message'] = "This username is already taken. Please choose another.";
        header("Location: registration.php");
        exit();
    }

    if (isValueTaken($conn, 'email', $email)) {
        $_SESSION['error_message'] = "An account with this email address already exists.";
        header("Location: registration.php");
        exit();
    }

    // Hash the password securely
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL INSERT statement
    $sql = "INSERT INTO tbluser (firstname, lastname, username, email, password, address, phone, birthdate, userType) 
            VALUES (:firstname, :lastname, :username, :email, :password, :address, :phone, :birthdate, 'student')";
    
    $stmt = $conn->prepare($sql);
    
    // Bind all parameters
    $stmt->bindParam(':firstname', $firstname);
    $stmt->bindParam(':lastname', $lastname);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':birthdate', $birthdate);

    // Execute the statement and redirect
    if ($stmt->execute()) {
        $_SESSION['registration_message'] = "Registration successful! You can now log in.";
        header("Location: login.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Registration failed. Please try again.";
        header("Location: registration.php");
        exit();
    }

} catch (PDOException $e) {
    // Log error for developers, show generic message to user
    error_log("Registration Error: " . $e->getMessage());
    $_SESSION['error_message'] = "A database error occurred. Please try again later.";
    header("Location: registration.php");
    exit();
}
