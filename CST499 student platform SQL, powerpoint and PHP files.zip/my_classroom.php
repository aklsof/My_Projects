<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Student-only access
if (!isset($_SESSION['user']) || $_SESSION['user']->userType !== 'student') {
    header("Location: index.php");
    exit();
}
$studentID = $_SESSION['user']->userID;
$all_my_courses = [];

try {
    $database = new Database();
    $conn = $database->getPDO();

    // Get enrolled courses and add a 'status' field
    $sqlEnrolled = "SELECT c.*, 'Enrolled' as status 
                    FROM Courses c 
                    JOIN Enrollments e ON c.courseID = e.courseID 
                    WHERE e.userID = :userID";
    $stmtEnrolled = $conn->prepare($sqlEnrolled);
    $stmtEnrolled->execute([':userID' => $studentID]);
    $enrolled_courses = $stmtEnrolled->fetchAll(PDO::FETCH_ASSOC);

    // Get waitlisted courses and add a 'status' field
    $sqlWaitlisted = "SELECT c.*, 'Waitlisted' as status 
                      FROM Courses c 
                      JOIN WaitingLists w ON c.courseID = w.courseID 
                      WHERE w.userID = :userID";
    $stmtWaitlisted = $conn->prepare($sqlWaitlisted);
    $stmtWaitlisted->execute([':userID' => $studentID]);
    $waitlisted_courses = $stmtWaitlisted->fetchAll(PDO::FETCH_ASSOC);

    // Combine both arrays
    $all_my_courses = array_merge($enrolled_courses, $waitlisted_courses);

} catch (PDOException $e) {
    die("Error fetching your courses: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Classroom</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <h2>My Classroom</h2>
        <p>A summary of your current enrolled and waitlisted courses.</p>
        <hr>
        <?php if (empty($all_my_courses)): ?>
            <p>You are not currently enrolled in or waitlisted for any courses. <a href="enroll.php">Enroll in courses now</a>.</p>
        <?php else: ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Instructor</th>
                        <th>Semester</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_my_courses as $course): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($course['courseCode']); ?></td>
                            <td><?php echo htmlspecialchars($course['courseName']); ?></td>
                            <td><?php echo htmlspecialchars($course['instructor']); ?></td>
                            <td><?php echo htmlspecialchars($course['semester']); ?></td>
                            <td>
                                <?php if ($course['status'] == 'Enrolled'): ?>
                                    <span class="badge bg-success">Enrolled</span>
                                <?php else: ?>
                                    <span class="badge bg-info text-dark">On Waitlist</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($course['status'] == 'Enrolled'): ?>
                                    <form action="enroll_process.php" method="POST" onsubmit="return confirm('Are you sure you want to withdraw from this course?');">
                                        <input type="hidden" name="courseID" value="<?php echo $course['courseID']; ?>">
                                        <input type="hidden" name="action" value="withdraw">
                                        <button type="submit" class="btn btn-sm btn-danger">Withdraw</button>
                                    </form>
                                <?php else: // Waitlisted ?>
                                    <form action="enroll_process.php" method="POST">
                                        <input type="hidden" name="courseID" value="<?php echo $course['courseID']; ?>">
                                        <input type="hidden" name="action" value="leave_waitlist">
                                        <button type="submit" class="btn btn-sm btn-warning">Leave Waitlist</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>