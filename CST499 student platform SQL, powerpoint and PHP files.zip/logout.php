<?php
// Start the session if it's not already started
// This is necessary to access session variables and functions
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Unset all session variables
// This removes all data stored in the current session
$_SESSION = array();

// Destroy the session
// This deletes the session file on the server
session_destroy();

// Invalidate the session cookie
// This makes sure the user's browser discards the session cookie
// and cannot use it to resume the old session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Redirect the user to the desired page after logout
// Commonly, this is the homepage or the login page
header("Location: index.php"); // Redirect to index.php
exit(); // Ensure that no further code is executed after the redirect

// You could also redirect to the login page:
// header("Location: login.php");
// exit();
?>