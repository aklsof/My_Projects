<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Admin-only access
if (!isset($_SESSION['user']) || $_SESSION['user']->userType !== 'administrator') {
    header("Location: index.php");
    exit();
}

try {
    $database = new Database();
    $conn = $database->getPDO();
    $stmt = $conn->query("SELECT * FROM Courses ORDER BY semester DESC, courseName ASC");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: Could not fetch courses.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Courses</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Manage Courses</h2>
            <a href="add_course.php" class="btn btn-primary">Add New Course</a>
        </div>
        <p>Here you can edit or delete existing courses in the catalog.</p>
        <hr>

        <?php
        if (isset($_SESSION['success_message'])) {
            echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
            unset($_SESSION['success_message']);
        }
        ?>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Instructor</th>
                        <th>Semester</th>
                        <th>Capacity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($courses)): ?>
                        <tr>
                            <td colspan="6" class="text-center">No courses found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($courses as $course): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($course['courseCode']); ?></td>
                                <td><?php echo htmlspecialchars($course['courseName']); ?></td>
                                <td><?php echo htmlspecialchars($course['instructor']); ?></td>
                                <td><?php echo htmlspecialchars($course['semester']); ?></td>
                                <td><?php echo htmlspecialchars($course['maxCapacity']); ?></td>
                                <td>
                                    <a href="edit_course.php?id=<?php echo $course['courseID']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                                    <form action="manage_courses_process.php" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this course?');">
                                        <input type="hidden" name="courseID" value="<?php echo $course['courseID']; ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>