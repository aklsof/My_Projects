<?php
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Student-only access
if (!isset($_SESSION['user']) || $_SESSION['user']->userType !== 'student') {
    header("Location: index.php");
    exit();
}

$studentID = $_SESSION['user']->userID;

try {
    $database = new Database();
    $conn = $database->getPDO();

    // Get all courses with their current enrollment count
    $sql = "SELECT c.*, COUNT(e.courseID) as enrolledCount 
            FROM Courses c 
            LEFT JOIN Enrollments e ON c.courseID = e.courseID 
            GROUP BY c.courseID 
            ORDER BY c.semester DESC, c.courseName ASC";
    $stmt = $conn->query($sql);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get IDs of courses this student is already enrolled in or waitlisted for
    $enrolledStmt = $conn->prepare("SELECT courseID FROM Enrollments WHERE userID = :userID");
    $enrolledStmt->execute([':userID' => $studentID]);
    $enrolledCourseIDs = $enrolledStmt->fetchAll(PDO::FETCH_COLUMN, 0);

    $waitlistStmt = $conn->prepare("SELECT courseID FROM WaitingLists WHERE userID = :userID");
    $waitlistStmt->execute([':userID' => $studentID]);
    $waitlistedCourseIDs = $waitlistStmt->fetchAll(PDO::FETCH_COLUMN, 0);

} catch (PDOException $e) {
    die("Error: Could not fetch course catalog.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enroll in Courses</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <h2>Enroll in Courses</h2>
        <p>Browse the course catalog and enroll in available courses.</p>
        <hr>
        <?php
        if (isset($_SESSION['success_message'])) {
            echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
            unset($_SESSION['success_message']);
        }
        ?>
        <div class="row">
            <?php foreach ($courses as $course): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($course['courseName']); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($course['courseCode']); ?> - <?php echo htmlspecialchars($course['semester']); ?></h6>
                            <p class="card-text"><strong>Instructor:</strong> <?php echo htmlspecialchars($course['instructor']); ?></p>
                            <p class="card-text"><strong>Seats Available:</strong> <?php echo $course['maxCapacity'] - $course['enrolledCount']; ?> / <?php echo $course['maxCapacity']; ?></p>
                        </div>
                        <div class="card-footer">
                            <?php
                            $isEnrolled = in_array($course['courseID'], $enrolledCourseIDs);
                            $isWaitlisted = in_array($course['courseID'], $waitlistedCourseIDs);
                            $isFull = $course['enrolledCount'] >= $course['maxCapacity'];

                            if ($isEnrolled) {
                                echo '<button class="btn btn-success w-100" disabled>Enrolled</button>';
                            } elseif ($isWaitlisted) {
                                echo '<button class="btn btn-info w-100" disabled>On Waitlist</button>';
                            } elseif ($isFull) {
                                echo '<form action="enroll_process.php" method="POST">
                                        <input type="hidden" name="courseID" value="' . $course['courseID'] . '">
                                        <input type="hidden" name="action" value="waitlist">
                                        <button type="submit" class="btn btn-warning w-100">Join Waitlist</button>
                                      </form>';
                            } else {
                                echo '<form action="enroll_process.php" method="POST">
                                        <input type="hidden" name="courseID" value="' . $course['courseID'] . '">
                                        <input type="hidden" name="action" value="enroll">
                                        <button type="submit" class="btn btn-primary w-100">Enroll</button>
                                      </form>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>