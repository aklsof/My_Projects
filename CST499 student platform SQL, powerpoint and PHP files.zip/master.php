<?php
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fa;
        }
        .welcome-card {
            margin-top: 5rem;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
    </style>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link href="style.css" rel="stylesheet">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Student platfom</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                 <li class="nav-item">
                     <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="financial_aid.php">Financial Aid</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <?php if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User): ?>
                    
                    <?php // Links for logged-in users of any type ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>

                    <?php if ($_SESSION['user']->userType == 'student'): ?>
                        <?php // Student-specific links ?>
                        <li class="nav-item">
                            <a class="nav-link" href="enroll.php">Enroll in Courses</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="enrolled_courses.php">My Courses</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="my_waitlist.php">My Waitlist</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="my_classroom.php">Classroom</a>
                        </li>

                    <?php elseif ($_SESSION['user']->userType == 'administrator'): ?>
                        <?php // Administrator-specific links ?>
                        <li class="nav-item">
                            <a class="nav-link" href="enrollment_approval.php">Enrollment Approval</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="manage_courses.php">Manage Courses</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link" href="add_course.php">Add New Course</a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link" href="index.php?logout=1">Logout</a>
                    </li>

                <?php else: ?>
                    <?php // Links for guests (not logged in) ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Log In</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="registration.php">Registration</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

