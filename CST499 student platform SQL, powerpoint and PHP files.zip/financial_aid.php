<?php
require_once __DIR__ . '/include/user.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Aid - Student Platform</title>
</head>
<body>
    <?php include 'master.php'; ?>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Financial Aid Information</h1>
                <p class="card-text">Information about financial aid options, scholarships, and application procedures will be available here.</p>
                <p>Please check back later for updates or contact the administration office for immediate assistance.</p>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>