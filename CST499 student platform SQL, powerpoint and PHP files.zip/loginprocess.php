<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';

// Start the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// If user is already logged in, redirect them
if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User) {
    header("Location: index.php");
    exit();
}

// Process the form only if it's a POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login_identifier = htmlspecialchars(filter_input(INPUT_POST, 'login_identifier', FILTER_DEFAULT) ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login_identifier) || empty($password)) {
        $_SESSION['error_message'] = "Username/Email and password are required.";
        header("Location: login.php");
        exit();
    }
    
    try {
        $database = new Database();
        $conn = $database->getPDO();
        // The column in your database is named 'password', not 'passwordHash'
        $sql = "SELECT * FROM tbluser WHERE username = :login_identifier OR email = :login_identifier";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':login_identifier', $login_identifier, PDO::PARAM_STR);
        $stmt->execute();
        $user_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user_data && password_verify($password, $user_data['password'])) {
            $userObject = null;
            if ($user_data['userType'] === 'student') {
                // CORRECTED CONSTRUCTOR CALL with userID and in the right order
                $userObject = new Student(
                    $user_data['id'], 
                    $user_data['email'],
                    $user_data['firstName'],
                    $user_data['lastName'],
                    $user_data['phone'],
                    $user_data['address'],
                     $user_data['username'],  
                    $user_data['birthdate']  
                );
            } elseif ($user_data['userType'] === 'administrator') {
                // CORRECTED CONSTRUCTOR CALL for Administrator
                $userObject = new Administrator(
                    $user_data['id'], 
                    $user_data['email'],
                    $user_data['firstName'],
                    $user_data['lastName'],
                    $user_data['phone'],
                    $user_data['address'],
                    $user_data['username'],  
                    $user_data['birthdate']  
                );
            }

            if ($userObject) {
                $_SESSION['user'] = $userObject;
                session_regenerate_id(true);
                header("Location: index.php");
                exit();
            } else {
                $_SESSION['error_message'] = "Invalid user role found.";
                header("Location: login.php");
                exit();
            }
        } else {
            $_SESSION['error_message'] = "Invalid username/email or password.";
            header("Location: login.php");
            exit();
        }
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        $_SESSION['error_message'] = "A database error occurred.";
        header("Location: login.php");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>