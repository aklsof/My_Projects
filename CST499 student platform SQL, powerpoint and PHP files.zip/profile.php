<?php


// Require class definitions. This is crucial for PHP to understand the object stored in the session.
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';


// Start the session at the very beginning
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// --- Authentication Check ---
// If 'user' is not set in the session or is not a User object, the user is not logged in.
if (!isset($_SESSION['user']) || !($_SESSION['user'] instanceof User)) {
    // Set a message to inform the user why they were redirected
    $_SESSION['error_message'] = "You must be logged in to view your profile.";
    // Redirect to the login page
    header("Location: login.php");
    exit(); // Stop script execution
}

// If the check passes, retrieve the user object from the session for easy access
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>User Profile</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
    .profile-container {
        margin-top: 50px;
    }
    .panel-heading {
        font-size: 1.5em;
        font-weight: bold;
    }
    .dl-horizontal dt {
        text-align: left;
        width: 140px; /* Adjusted for longer labels */
        white-space: normal;
    }
    .dl-horizontal dd {
        margin-left: 160px; /* Adjusted for longer labels */
        margin-bottom: 15px; /* Adds space between items */
    }
</style>
</head>
<body>

<?php require 'master.php'; ?>

<div class="container profile-container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-user"></span> Profile Details
                </div>
                <div class="panel-body">
                    <dl class="dl-horizontal">
                        <dt>Full Name:</dt>
                        <dd><?php echo htmlspecialchars($user->getFullName()); ?></dd>

                        <dt>Username:</dt>
                        <dd><?php echo htmlspecialchars($user->username); ?></dd>

                        <dt>Email Address:</dt>
                        <dd><?php echo htmlspecialchars($user->email); ?></dd>

                        <dt>Phone Number:</dt>
                        <dd><?php echo htmlspecialchars($user->phone); ?></dd>

                        <dt>Address:</dt>
                        <dd><?php echo htmlspecialchars($user->address); ?></dd>

                        <dt>Birthdate:</dt>
                        <dd><?php echo htmlspecialchars($user->birthdate); ?></dd>
                        
                        <dt>Account Type:</dt>
                        <dd><?php echo htmlspecialchars(ucfirst($user->userType)); ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>

</body>
</html>