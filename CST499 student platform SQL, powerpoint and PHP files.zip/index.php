<?php
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Log out process 
if (isset($_GET['logout']) && $_GET['logout'] == 1) {
   
    $_SESSION = array();
    session_destroy();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    header('Location: index.php'); 
    exit; 
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Enrollment Platform</title>
</head>
<body>

<?php require_once 'master.php'; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card welcome-card text-center">
                <div class="card-body">
                    <?php if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User): ?>
                        <h1 class="card-title">Welcome, <?php echo htmlspecialchars($_SESSION['user']->getFullName()); ?>!</h1>
                        <p class="card-text">You are logged in as a <?php echo htmlspecialchars($_SESSION['user']->userType); ?>.</p>
                        <p class="card-text">This is your personal dashboard. From here, you can manage your courses and profile.</p>
                        <a href="?logout=1" class="btn btn-danger">Logout</a>
                    <?php else: ?>
                        <h1 class="card-title">Welcome to the Student Enrollment Platform</h1>
                        <p class="card-text">Your one-stop solution for managing your academic journey.</p>
                        <p class="card-text">Please log in to access your dashboard or register for a new account to get started.</p>
                        <a href="login.php" class="btn btn-primary">Login</a>
                        <a href="registration.php" class="btn btn-secondary">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

