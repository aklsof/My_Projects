<?php
// Include all user-related class definitions FIRST
require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/user.php';
require_once __DIR__ . '/include/student.php';
require_once __DIR__ . '/include/administrator.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Security checks for admin and request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user']) || $_SESSION['user']->userType !== 'administrator') {
    header("Location: index.php");
    exit();
}

// Sanitize and retrieve form data
$courseCode = htmlspecialchars(filter_input(INPUT_POST, 'courseCode', FILTER_DEFAULT) ?? '');
$courseName = htmlspecialchars(filter_input(INPUT_POST, 'courseName', FILTER_DEFAULT) ?? '');
$description = htmlspecialchars(filter_input(INPUT_POST, 'description', FILTER_DEFAULT) ?? '');
$instructor = htmlspecialchars(filter_input(INPUT_POST, 'instructor', FILTER_DEFAULT) ?? '');
$semester = htmlspecialchars(filter_input(INPUT_POST, 'semester', FILTER_DEFAULT) ?? '');
$maxCapacity = filter_input(INPUT_POST, 'maxCapacity', FILTER_VALIDATE_INT);

// Validation
if (empty($courseCode) || empty($courseName) || empty($semester) || $maxCapacity === false || $maxCapacity < 1) {
    $_SESSION['error_message'] = "Invalid input. Please check all required fields.";
    header("Location: add_course.php");
    exit();
}

try {
    $database = new Database();
    $conn = $database->getPDO();
    $sql = "INSERT INTO Courses (courseCode, courseName, description, instructor, semester, maxCapacity) VALUES (:courseCode, :courseName, :description, :instructor, :semester, :maxCapacity)";
    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':courseCode', $courseCode);
    $stmt->bindParam(':courseName', $courseName);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':instructor', $instructor);
    $stmt->bindParam(':semester', $semester);
    $stmt->bindParam(':maxCapacity', $maxCapacity, PDO::PARAM_INT);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Course '{$courseName}' added successfully!";
        header("Location: manage_courses.php");
    } else {
        $_SESSION['error_message'] = "Failed to add course.";
        header("Location: add_course.php");
    }
} catch (PDOException $e) {
    error_log("Add Course Error: " . $e->getMessage());
    if ($e->errorInfo[1] == 1062) { // Handles duplicate entry for courseCode
        $_SESSION['error_message'] = "A course with that Course Code already exists.";
    } else {
        $_SESSION['error_message'] = "A database error occurred.";
    }
    header("Location: add_course.php");
}
exit();