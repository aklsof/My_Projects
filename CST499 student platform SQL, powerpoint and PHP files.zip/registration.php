<?php
// Start the session at the very beginning of the script
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Registration Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
    .form-container {
        margin-top: 50px;
    }
    .panel-login {
        border-color: #ddd;
    }
    .panel-login > .panel-heading {
        color: #000;
        background-color: #f5f5f5;
        border-color: #ddd;
        text-align: center;
        font-size: 1.5em;
    }
    .panel-login > .panel-body {
        padding: 25px;
    }
    .form-horizontal .form-group {
        margin-left: 0;
        margin-right: 0;
    }
    .form-horizontal .col-sm-10 {
        width: 100%;
        float: none;
        margin: 0 auto;
    }
    .form-horizontal .col-sm-offset-2 {
        margin-left: 0;
        text-align: center;
    }
    .form-horizontal .btn {
         float: none;
    }
    .password-info {
        font-size: 0.9em;
        color: #666;
    }
</style>
</head>
<body>
<?php include 'master.php'; ?>

<div class="container form-container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
            <div class="panel panel-login panel-default">
                <div class="panel-heading">
                    Register for an Account
                </div>
                <div class="panel-body">

                    <?php
                    // Check if an error message is set in the session and display it
                    if (isset($_SESSION['error_message'])) {
                        echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
                        // Unset the error message so it doesn't show again on refresh
                        unset($_SESSION['error_message']);
                    }
                    ?>

                    <form action="registration2.php" method="post" class="form-horizontal">

                        <div class="form-group">
                            <label for="firstname" class="col-sm-2 control-label">First Name:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastname" class="col-sm-2 control-label">Last Name:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label">Username:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter a user name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label">Email:</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-sm-2 control-label">Password:</label>
                            <div class="col-sm-10">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                                <p class="password-info">Password must be at least 12 characters and include uppercase, lowercase, number, and special character.</p>
                            </div>
                        </div>

                         <div class="form-group">
                            <label for="address" class="col-sm-2 control-label">Address:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="address" name="address" placeholder="Address" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="phone" class="col-sm-2 control-label">Phone:</label>
                            <div class="col-sm-10">
                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="Phone number" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="birthdate" class="col-sm-2 control-label">Birthdate:</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" id="birthdate" name="birthdate" placeholder="Date of birth" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" name="submit" class="btn btn-primary">Register</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>

