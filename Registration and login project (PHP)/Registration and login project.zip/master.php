<?php
error_reporting(E_ALL ^ E_NOTICE);

require_once __DIR__ . '/include/Employee.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="jumbotron">
<div class="container text-center">
<h1> My Website</h1>
</div>
</div>
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
    <span class="icon-bar"> Test 1</span>
    <span class="icon-bar">test2 </span>
    <span class="icon-bar"> test 3</span>
</button>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-exclamation-sign"></span> AboutUs</a></li>
<li><a href="#"><span class="glyphicon glyphicon-earphone"></span> ContactUs</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<?php
    if (isset($_SESSION['employee'])) {
        echo '<li><a href="profile.php"><span class="glyphicon glyphicon-briefcase"></span> Profile</a></li>';
        echo '<li><a href="index.php?logout=1"><span class="glyphicon glyphicon-off"></span> Logout</a></li>';
    } else {
        echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Login</a></li>';
        echo '<li><a href="registration.php"><span class="glyphicon glyphicon-pencil"></span> Registration</a></li>';
    }
?>
</ul>
</div>
</div>
</nav>