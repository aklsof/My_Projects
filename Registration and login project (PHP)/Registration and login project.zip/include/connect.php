<?php
$dsn = 'mysql:host=localhost;dbname=mydata';
$dbusername = 'root';
$dbpassword = '';
class Database {
    private $conn;
    public function __construct() {
        global $dsn, $dbusername, $dbpassword;
        try {
            $this->conn = new PDO($dsn, $dbusername, $dbpassword);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $error_message = $e->getMessage();
            echo "connexion failed: " . $error_message;
            include('../registration.php');
            exit();
        }
    }
    public function getPDO() {
        return $this->conn;
    }
}

?>