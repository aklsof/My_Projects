<?php

/**
 * Class Employee
 * Represents an employee with properties corresponding to the tbluser table.
 */
class Employee
{

    public $email;
    public $firstName;
    public $lastName;
    public $phone;
    public $address;
    public $salary;
    public $ssn;
    public $password; 

    public function __construct(
        $email,
        $firstName,
        $lastName,
        $phone = null,
        $address = null,
        $salary = null,
        $ssn = null,
        $password = null
    ) {
        $this->email = $email;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->phone = $phone;
        $this->address = $address;
        $this->salary = $salary;
        $this->ssn = $ssn;
        $this->password = $password; 
    }

    public function getFullName()
    {
        return $this->firstName . ' ' . $this->lastName;
    }

    public function getFormattedSalary()
    {
        $decimals = 2;
        $decimal_separator = '.';
        $thousands_separator = ',';
        if ($this->salary !== null) {
            return '$' . number_format($this->salary, $decimals, $decimal_separator, $thousands_separator);
        }
        return 'N/A';
    }
}