<?php
error_reporting(E_ALL ^ E_NOTICE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Profile Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
    /* Custom styles for the profile panel */
    .profile-container {
        margin-top: 30px; 
    }
    .panel-profile {
        border-color: #ddd; 
    }
    .panel-profile > .panel-heading {
        color: #000; 
        background-color: #f5f5f5; 
        border-color: #ddd;
        text-align: center; 
        font-size: 1.5em; 
    }
    .panel-profile > .panel-body {
        padding: 25px; 
    }
  
    .profile-details div {
        margin-bottom: 15px;
        padding-bottom: 15px; 
        border-bottom: 1px solid #eee; 
    }
    .profile-details div:last-child {
        margin-bottom: 0;
        padding-bottom: 5;
        border-bottom: none; 
    }
    .profile-details strong {
        display: inline-block; 
        width: 150px; 
        margin-right: 10px; 
        text-align: right; 
    }

    /* Responsive adjustments for smaller screens */
    @media (max-width: 767px) {
        .profile-details strong {
            width: auto; 
            text-align: left; 
            display: block; 
            margin-right: 0;
            margin-bottom: 5px;
        }
    }

</style>
</head>
<body>
<?php include 'master.php'; ?>

<div class="container text-center">
<h1>Welcome    <?php
      
        if (isset($_SESSION['employee']) && $_SESSION['employee'] instanceof Employee) {
            echo htmlspecialchars($_SESSION['employee']->getFullName());
        }
        ?> to the Profile page</h1>
</div>
    <?php 
      
        if (isset($_SESSION['employee']) && $_SESSION['employee'] instanceof Employee) {

           ?>
           <div class="container profile-container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
            <div class="panel panel-profile panel-default">
                <div class="panel-heading">
                    Employee Profile Details
                </div>
                <div class="panel-body profile-details">
                    <div>
                        <strong>First Name:</strong> <?php echo htmlspecialchars($_SESSION['employee']->firstName); ?>
                    </div>
                    <div>
                        <strong>Last Name:</strong> <?php echo htmlspecialchars($_SESSION['employee']->lastName); ?>
                    </div>
                    <div>
                        <strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['employee']->email); ?>
                    </div>
                    <div>
                        <strong>Phone Number:</strong> <?php echo htmlspecialchars($_SESSION['employee']->phone); ?>
                    </div>
                     <div>
                        <?php 
                        if (isset($_GET['pass']) && $_GET['pass'] == 1) {
                            ?>

                        <strong>Password:</strong> <?php echo htmlspecialchars($_SESSION['employee']->password);
                        }
                        else { ?> <a href="profile.php?pass=1" > Show your password</a> <?php } ?>

                    </div>
                    <div>
                        <strong>Address:</strong> <?php echo htmlspecialchars($_SESSION['employee']->address); ?>
                    </div>
                    <div>
                        <strong>Salary:</strong> <?php echo htmlspecialchars($_SESSION['employee']->getFormattedSalary()); ?>
                    </div>
                    <div> <?php
                         if (isset($_GET['ssn1']) && $_GET['ssn1'] == 1) {
                            ?>
                        <strong>Social Security Number:</strong> <?php echo htmlspecialchars($_SESSION['employee']->ssn);  }
                        else { ?> <a href="profile.php?ssn1=1" > Show your SSN number</a> <?php } ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
        }
        else {
            ?>
             <div class="container profile-container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
            <div class="panel panel-profile panel-default">
                <div class="panel-heading">
                    Important information
                </div>
                <div class="panel-body profile-details">
                    <div>
                         <strong> Please <a href= 'login.php'> login </a> </strong> to get access to your account 
                    </div>
                    
            </div>
        </div>
    </div>
</div>
       
            <?php
        }
 include 'footer.php';
  ?>
</body>
</html>