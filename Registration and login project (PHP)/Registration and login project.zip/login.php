<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Login Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
    
    .form-container {
        margin-top: 50px; 
    }
    .panel-login {
        border-color: #ddd; 
    }
    .panel-login > .panel-heading {
        color: #000; 
        background-color: #f5f5f5; 
        border-color: #ddd;
        text-align: center; 
        font-size: 1.5em; 
    }
    .panel-login > .panel-body {
        padding: 25px; 
    }

    .form-horizontal .form-group {
        margin-left: 0;
        margin-right: 0;
    }

    .form-horizontal .col-sm-10 {
        width: 100%; 
        float: none; 
        margin: 0 auto; 
    }
    /* Center the button */
    .form-horizontal .col-sm-offset-2 {
        margin-left: 0; 
        text-align: center; 
    }
    .form-horizontal .btn {
         float: none; 
    }

</style>
</head>
<body>
<?php
require 'master.php';
?>
<div class="container form-container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
            <div class="panel panel-login panel-default">
                <div class="panel-heading">
                    Login to Your Account
                </div>
                <div class="panel-body">
                    <?php
                    // Display error message if set in session
                    if (isset($_SESSION['error_message'])) {
                        echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
                        unset($_SESSION['error_message']); // Clear the error message after displaying
                    }
                    if (isset($_SESSION['registration_message'])) {
                       echo '<div class="alert alert-info" role="alert">' . htmlspecialchars($_SESSION['registration_message']) . '</div>';
                        unset($_SESSION['registration_message']); 
                     }
                    ?>
                    <form action="loginprocess.php" method="post" class="form-horizontal">
                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label">Email:</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-sm-2 control-label">Password:</label>
                            <div class="col-sm-10">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary">Sign in to your account</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>
</body>
</html>
