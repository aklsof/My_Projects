<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/include/connect.php';
require_once __DIR__ . '/include/Employee.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if (isset($_SESSION['employee']) && $_SESSION['employee'] instanceof Employee) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $database = new Database();
    $conn = $database->getPDO();
    $sql = "SELECT email, firstName, lastName, phone, address, salary, ssn, password FROM tbluser WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);

    try {
        $stmt->execute();
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        $_SESSION['error_message'] = "An error occurred during login. Please try again.";
        header("Location: login.php");
        exit();
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($user && password_verify($password, $user['password'])) {
        // Login successful

  
        $employee = new Employee(
            $user['email'],
            $user['firstName'],
            $user['lastName'],
            $user['phone'],
            $user['address'],
            $user['salary'],
            $user['ssn'],
            $user['password']
        );

        // Store the Employee object in the session
        $_SESSION['employee'] = $employee;
        $_SESSION['employee']->password = $password;

        // Regenerate session ID for security
        session_regenerate_id(true);

        // Redirect to the index page
        header("Location: index.php");
        exit();
    } else {
        // Invalid credentials
        $_SESSION['error_message'] = "Invalid email or password.";
        header("Location: login.php"); // Redirect back to login page
        exit();
    }

} else {
    // Not a POST request
    $_SESSION['error_message'] = "Access not allowed. Please submit the login form.";
    header("Location: login.php");
    exit();
}
