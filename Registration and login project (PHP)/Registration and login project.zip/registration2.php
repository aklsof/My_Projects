<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once 'include/connect.php';
Class register {
public function registerUser() {

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $ssn = $_POST['ssn'];
    $salary = $_POST['salary'];

        }
        else {
            header("Location: index.php");
        exit();
    }
    
    
    try {
        $db = new Database();
        $pdo = $db->getPDO();
        
        $query = "INSERT INTO tbluser (email, password, firstname, lastname, phone, address, ssn, salary) 
                 VALUES (?, ?, ?, ?, ?, ?, ?,?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$email, $password, $firstname, $lastname, $phone, $address,$ssn,$salary]);
        
        header("Location: login.php?registration_message ='Success registration']");
        exit();
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
}
$registrationProcess = new register();
$registrationProcess->registerUser();
?>