-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2025 at 07:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydata`
--
CREATE DATABASE IF NOT EXISTS `mydata` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mydata`;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `salary` float DEFAULT NULL,
  `SSN` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `email`, `password`, `firstName`, `lastName`, `address`, `phone`, `salary`, `SSN`) VALUES
(1, 'aklsof@gmail.com', '$2y$10$6Xg1HzLTTNXI6IjiTAUlGOp3EeOJIYS7cGVKX2GMj48ZDcXQaZYo2', 'Sofiane', 'Akli', '22816 28th Ave S', '2063339999', 8500050, '123456789'),
(2, 'jacson@yahoone', '$2y$10$ITY6.hB8O57KwQHTLRRSSeKh5.3VrAQfdqmv5zUrdUECBmhbqHP2S', 'Robert ', 'Jackson', '2522 main st', '4501235554', 5000, '123456789'),
(3, 'Johnrobert@gmail.com', '$2y$10$PeUdEj3N0ruxmhTkEf7HIOrZLocKVz6T6aKFxme3aPE7nPhieLOdK', 'John', 'robert', '226 m st', '4202221455', 12000, '147258369'),
(4, 'joe@live.net', '$2y$10$SqNkf5h2mGyemmIwWUU6HOVNVOhSEIK8oDuOc/MK33Minv0M637CK', 'joe', 'masters', '78 ave s', '4152225656', 147258000, '147258369'),
(5, 'john11@live.com', '$2y$10$sqvzLGzWWYLrVRIZrL2BOesn8rvrXYaYnGBLP1PUXIyTRi8qdSarC', 'SOFIANE', 'Akli', '22816 28TH AVE S', '2067750761', 52000, '123456789');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
